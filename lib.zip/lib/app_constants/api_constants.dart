String baseurl = "bharatbills.in";
String suburl = "bb";
String reqfrom = "app";
String apikey = "123";
String bill_file_api_key = "kdshj21455632bjchbdDCNKSN";
String glogkey = "eee118a6fa4d9906f010c0272ce57947";